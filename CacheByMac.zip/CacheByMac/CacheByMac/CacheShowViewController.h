//
//  CacheShowViewController.h
//  CacheByMac
//
//  Created by 杨 宏强 on 13-2-21.
//  Copyright (c) 2013年 yanghongqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CacheShowViewController : UIViewController
@property (strong, nonatomic) NSURL *imageURL;

@property (strong, nonatomic) IBOutlet UIImageView *imageView;


@end
